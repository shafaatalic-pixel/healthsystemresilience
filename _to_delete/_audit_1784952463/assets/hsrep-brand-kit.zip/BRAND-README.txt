HSREP — Health System Resilience & Economic Protection
Brand marks for press, partners, and institutional use.
Aligned to the HSREP Definitive Institutional Brand System (2026).

────────────────────────────────────────────────────────
THE MARKS IN THIS KIT
- hsrep-logo-primary-navy.svg   Primary horizontal lockup (crest + wordmark), full colour — for light backgrounds. Default mark.
- hsrep-logo-primary-white.svg  Primary horizontal lockup, reversed white — for controlled dark backgrounds only.
- hsrep-crest.png               The Humanist Crest (icon), for avatars and navigation at 64 px or larger.

Use the horizontal lockup by default. In extremely narrow spaces where the
crest cannot stay legible, use the wordmark rather than shrinking the crest.

────────────────────────────────────────────────────────
COLOUR
Core palette (only these define the brand):
  Deep Navy   #1C2E4A   institution, authority, headings, dark bands
  Vital Coral #F26D5A   the single human accent — the "point of life"; one per view
  Charcoal    #5A5F66   secondary text
  Soft Slate  #8A9099   metadata, dividers, quiet information
  White       #FFFFFF   primary field and breathing space
Coral is a signal, not a field colour, and never carries paragraphs or small
text. Green (#267A69) is not a brand colour — use it only inside charts when
"positive" is methodologically defined.

TYPOGRAPHY
  Display / headlines .... Spectral   (fallback: Georgia, serif)
  Body / interface ....... Inter      (fallback: Arial / system sans)
  Labels / data / § ...... IBM Plex Mono (fallback: Courier New, monospace)

────────────────────────────────────────────────────────
USING THE LOGO
- Clear space: keep at least one "X" of space on every side, where X is the
  diameter of the coral point.
- Minimum size: the crest/icon is for use at 64 px and up. Do not use the crest
  at 16, 24 or 32 px; use the wordmark or the platform's own placeholder instead.
- Do not: recolour, tint or add opacity to the mark; add shadow, glow, outline,
  bevel, texture or gradient; close the arch gaps; equalise the three figures;
  move the coral point; or add medical clichés (cross, ECG, heart, stethoscope).
- Do not rebuild a lockup by combining separate files, and do not extract crest
  elements into new logos or badges.

WRITING THE NAME
Write HSREP in uppercase. On first formal mention, spell it out:
Health System Resilience & Economic Protection (HSREP). Never use HSREP as a verb.

────────────────────────────────────────────────────────
APPROVED WORDING
Principle:        Human in purpose. Systemic in method. Protective in outcome.
Core proposition: Health protection is economic infrastructure, not a residual budget line.
One sentence:     HSREP is an independent policy-research and advocacy platform
                  examining health-system resilience as economic protection infrastructure.

Partner marks: use verified files and written permission; follow each owner's rules.
Contact & full kit: hsraep.org/media
