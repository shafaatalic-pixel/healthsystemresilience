HSREP — Health System Resilience & Economic Protection
Brand marks for press, partners, and institutional use.

Files:
- hsrep-wordmark-navy.svg   Primary wordmark, navy — for light backgrounds
- hsrep-wordmark-white.svg  Primary wordmark, white — for dark backgrounds
- hsrep-crest.png           The Humanist Crest (icon)

Colors: Navy #1C2E4A · Coral #F26D5A · Green #267A69
Please keep clear space around the mark and do not recolor or distort it.
Contact: hsraep.org
